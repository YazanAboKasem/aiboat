<?php $__env->startSection('styles'); ?>
<style>
    .chat-container {
        height: 70vh;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        padding: 15px;
    }
    .message {
        max-width: 75%;
        padding: 10px 15px;
        margin-bottom: 10px;
        border-radius: 15px;
        position: relative;
    }
    .message-time {
        font-size: 0.7rem;
        color: #888;
        margin-top: 5px;
    }
    .message-incoming {
        align-self: flex-start;
        background-color: #f1f0f0;
        border-bottom-left-radius: 5px;
    }
    .message-outgoing {
        align-self: flex-end;
        background-color: #dcf8c6;
        border-bottom-right-radius: 5px;
    }
    .message-attachment {
        max-width: 100%;
        margin-top: 10px;
    }
    .source-badge {
        position: absolute;
        top: -10px;
        font-size: 0.7rem;
    }
    .facebook-badge {
        background-color: #3b5998;
        color: white;
    }
    .instagram-badge {
        background-color: #833AB4;
        color: white;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">
                            Conversation with: <?php echo e($conversation->first()->sender_name ?? $senderId); ?>

                            <?php if($source === 'facebook'): ?>
                                <span class="badge bg-primary ms-2">Facebook</span>
                            <?php elseif($source === 'instagram'): ?>
                                <span class="badge bg-info ms-2">Instagram</span>
                            <?php endif; ?>
                        </h4>
                        <a href="<?php echo e(route('messages.index')); ?>" class="btn btn-light btn-sm">
                            Back to List
                        </a>
                    </div>

                    <div class="chat-container" id="chat-container">
                        <?php $__currentLoopData = $conversation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="message <?php echo e($message->is_reply ? 'message-outgoing' : 'message-incoming'); ?>">
                                <?php if($message->source === 'facebook'): ?>
                                    <span class="badge facebook-badge source-badge">Facebook</span>
                                <?php elseif($message->source === 'instagram'): ?>
                                    <span class="badge instagram-badge source-badge">Instagram</span>
                                <?php endif; ?>

                                <div><?php echo e($message->message); ?></div>

                                <?php if($message->attachment_url): ?>
                                    <div class="message-attachment">
                                        <?php if(in_array($message->attachment_type, ['image', 'photo'])): ?>
                                            <img src="<?php echo e($message->attachment_url); ?>" alt="Attachment" class="img-fluid">
                                        <?php elseif($message->attachment_type === 'video'): ?>
                                            <video controls class="img-fluid">
                                                <source src="<?php echo e($message->attachment_url); ?>" type="video/mp4">
                                                Your browser does not support video playback
                                            </video>
                                        <?php elseif($message->attachment_type === 'audio'): ?>
                                            <audio controls>
                                                <source src="<?php echo e($message->attachment_url); ?>" type="audio/mpeg">
                                                Your browser does not support audio playback
                                            </audio>
                                        <?php else: ?>
                                            <a href="<?php echo e($message->attachment_url); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                                View Attachment
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>

                                <div class="message-time">
                                    <?php echo e($message->created_at->format('Y-m-d H:i:s')); ?>

                                    <?php if($message->is_reply === false && $message->read_at): ?>
                                        <span class="text-success">✓ Read</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="card-footer">
                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('messages.reply', $senderId)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="source" value="<?php echo e($source); ?>">

                            <div class="input-group">
                                <input type="text" name="message" class="form-control" placeholder="Type your message here..." required>
                                <button type="submit" class="btn btn-primary">Send</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Scroll to bottom of chat when page loads
        document.addEventListener('DOMContentLoaded', function() {
            var chatContainer = document.getElementById('chat-container');
            chatContainer.scrollTop = chatContainer.scrollHeight;
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/yazan/igfb-bot/resources/views/messages/show.blade.php ENDPATH**/ ?>