<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Conversations List</h4>
                    </div>
                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if($conversations->isEmpty()): ?>
                            <div class="alert alert-info">
                                No conversations available.
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead class="thead-light">
                                        <tr>
                                            <th>Sender</th>
                                            <th>Platform</th>
                                            <th>Message Count</th>
                                            <th>Last Updated</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php echo e($conversation->sender_id); ?>

                                                    <?php if(App\Models\Message::where('sender_id', $conversation->sender_id)->where('is_reply', false)->whereNull('read_at')->exists()): ?>
                                                        <span class="badge bg-danger">New</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($conversation->source === 'facebook'): ?>
                                                        <span class="badge bg-primary">Facebook</span>
                                                    <?php elseif($conversation->source === 'instagram'): ?>
                                                        <span class="badge bg-info">Instagram</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e($conversation->message_count); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('messages.show', $conversation->sender_id)); ?>" class="btn btn-sm btn-primary">
                                                        View Conversation
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/yazan/igfb-bot/resources/views/messages/index.blade.php ENDPATH**/ ?>